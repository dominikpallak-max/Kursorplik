package snipevoid.kursor;

import net.fabricmc.api.ClientModInitializer;

public class KursorPlikMod implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        KursorPlik.init();
    }
}
