package snipevoid.kursor;

import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public class KursorPlikScreen extends Screen {
    private final Screen parent;
    private ButtonWidget toggleButton;

    public KursorPlikScreen(Screen parent) {
        super(Text.literal("Kursor plik"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int cx = this.width / 2;
        int cy = this.height / 2;

        this.toggleButton = ButtonWidget.builder(label(), b -> {
            KursorPlik.enabled = !KursorPlik.enabled;
            b.setMessage(label());
        }).dimensions(cx - 100, cy - 10, 200, 20).build();
        this.addDrawableChild(this.toggleButton);

        this.addDrawableChild(ButtonWidget.builder(Text.literal("Zamknij"), b -> this.close())
                .dimensions(cx - 100, cy + 15, 200, 20).build());
    }

    private static Text label() {
        return Text.literal("Kursor plik: " + (KursorPlik.enabled ? "WŁĄCZONY" : "WYŁĄCZONY"));
    }

    @Override
    public void close() {
        this.client.setScreen(parent);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
